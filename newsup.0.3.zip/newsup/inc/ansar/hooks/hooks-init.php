<?php
/**
 * Header section.
 */
require get_template_directory().'/inc/ansar/hooks/hook-header-section.php';

/**
 * Exclusive posts additions.
 */
require get_template_directory().'/inc/ansar/hooks/hook-front-page-banner-exclusive-posts.php';

/**
 * Trending posts additions.
 */
require get_template_directory().'/inc/ansar/hooks/hook-front-page-banner-tabbed-posts.php';


/**
 * ticker additions.
 */
require get_template_directory().'/inc/ansar/hooks/hook-front-page-banner-promotions.php';

/**
 * Featured posts additions.
 */
require get_template_directory().'/inc/ansar/hooks/hook-front-page-banner-featured-posts.php';

/**
 * banner additions.
 */
require get_template_directory().'/inc/ansar/hooks/hook-front-page-main-banner-section.php';

/**
 * Front page section additions.
 */
require get_template_directory().'/inc/ansar/hooks/hook-meta.php';