<?php
$newsup_slider_category = newsup_get_option('select_slider_news_category');
$newsup_number_of_slides = newsup_get_option('number_of_slides');
$all_posts_main = newsup_get_posts($newsup_number_of_slides, $newsup_slider_category);
$count = 1;

if ($all_posts_main->have_posts()) :
    while ($all_posts_main->have_posts()) : $all_posts_main->the_post();

        global $post;
        $url = newsup_get_freatured_image_url($post->ID, 'newsup-slider-full');

        ?>
         <div class="item">
            <div class="mg-blog-post lg">
                <div class="mg-blog-img">
                 <a class="ta-slide-items" href="<?php the_permalink(); ?>">
                    <?php if (!empty($url)): ?>
                        <img src="<?php echo esc_url($url); ?>">
                    <?php endif; ?>
                    </a>
                </div>

                <article class="bottom">
                        <span class="post-form"><i class="fa fa-camera"></i></span>
                        <div class="mg-blog-category"> <?php newsup_post_categories(); ?> </div>
                        <h1 class="title"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                        <div class="mg-blog-meta"> 
                        <?php newsup_post_item_meta(); ?>
                        </div>
                </article>
            </div>
        </div>
    <?php
    endwhile;
endif;
wp_reset_postdata();
?>