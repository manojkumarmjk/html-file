<?php
if (!function_exists('newsup_front_page_banner_section')) :
    /**
     *
     * @since Newsup
     *
     */
    function newsup_front_page_banner_section()
    {
        if (is_front_page() || is_home()) {
        $newsup_enable_main_slider = newsup_get_option('show_main_news_section');
        $select_vertical_slider_news_category = newsup_get_option('select_vertical_slider_news_category');
        $vertical_slider_number_of_slides = newsup_get_option('vertical_slider_number_of_slides');
        $all_posts_vertical = newsup_get_posts($vertical_slider_number_of_slides, $select_vertical_slider_news_category);
        if ($newsup_enable_main_slider): ?>
        <section class="mg-fea-area">
            <div class="overlay">
                <div class="container-fluid">
                    <div class="">
                        <div class="col-md-8">
                            <div class="row">
                                <div id="homemain"class="homemain owl-carousel mr-bot60"> 
                                <?php newsup_get_block('list', 'banner'); ?>
                                </div>
                            </div>
                        </div> 
                        <?php do_action('newsup_action_banner_tabbed_posts');?>
                    </div>
                </div>
            </div>
        </section>
        <!--==/ Home Slider ==-->
        <?php endif; ?>
        <!-- end slider-section -->
        <?php }
    }
endif;
add_action('newsup_action_front_page_main_section_1', 'newsup_front_page_banner_section', 40);