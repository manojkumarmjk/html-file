<?php
/**
 * Recommended Plugins Panel
 *
 * @package Newsup
 */
?>
<div id="recommended-plugins-panel" class="panel-left">
	<?php 
	$free_plugins = array(
		'shortbuild' => array(
		    'name'      => 'Shortbuild',
			'slug'     	=> 'shortbuild',
			'filename' 	=> 'shortbuild.php',
		),

		'one-click-demo-import' => array(
		    'name'     	=> 'One Click Demo Import',
			'slug'     	=> 'one-click-demo-import',
			'filename' 	=> 'one-click-demo-import.php',
		),
	);
	if( !empty( $free_plugins ) ) { ?>
		<div class="recomended-plugin-wrap">
		<?php
		foreach( $free_plugins as $plugin ) {
			$info 		= newsup_call_plugin_api( $plugin['slug'] ); ?>
			<div class="recom-plugin-wrap mb-0">
				<div class="plugin-title-install clearfix">
					<span class="title" title="<?php echo esc_attr( $plugin['name'] ); ?>">
					<?php echo esc_html( $plugin['name'] ); ?>
					</span>
					<?php if($plugin['slug'] == 'shortbuild') : ?>
					<p><?php esc_html_e('To access the advanced Frontpage sections and the other features, please install the Shortbuild plugin.', 'newsup'); ?></p>
					<?php endif; ?>
					<?php if($plugin['slug'] == 'one-click-demo-import') : ?>
					<p><?php esc_html_e('Install and activate one click demo import plugin, then go to Theme Dashboard >> appreance >> Import Demo Data then click import button', 'newsup'); ?></p>
					<?php endif; ?>
					<?php echo '<div class="button-wrap">';
					echo Newsup_Getting_Started_Page_Plugin_Helper::instance()->get_button_html( $plugin['slug'] );
					echo '</div>';
					?>
				</div>
			</div>
			</br>
			<?php
		} ?>
		</div>
	<?php
	} ?>
</div>