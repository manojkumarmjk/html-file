<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Newsup
 */
if ( ! is_active_sidebar( 'front-page-content' ) ) {
	return;
}
?>
<div class="col-md-8 col-sm-8">
	<div class="">
		<?php dynamic_sidebar( 'front-page-content' );
		 ?>
	</div>
</div>